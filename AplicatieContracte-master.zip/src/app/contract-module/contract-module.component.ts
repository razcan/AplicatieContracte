import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-contract-module',
  templateUrl: './contract-module.component.html',
  styleUrls: ['./contract-module.component.css']
})
export class ContractModuleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
