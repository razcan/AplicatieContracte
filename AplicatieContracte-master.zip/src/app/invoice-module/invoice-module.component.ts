import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invoice-module',
  templateUrl: './invoice-module.component.html',
  styleUrls: ['./invoice-module.component.css']
})
export class InvoiceModuleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
