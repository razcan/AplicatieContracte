import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-department-details',
  templateUrl: './department-details.component.html',
  styleUrls: ['./department-details.component.css']
})
export class DepartmentDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
