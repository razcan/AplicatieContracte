import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gestiuni',
  templateUrl: './gestiuni.component.html',
  styleUrls: ['./gestiuni.component.css']
})
export class GestiuniComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
